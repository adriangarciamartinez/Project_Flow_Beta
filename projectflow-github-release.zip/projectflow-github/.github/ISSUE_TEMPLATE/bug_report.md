---
name: Bug report
about: Something isn't working as expected
title: '[Bug] '
labels: bug
assignees: ''
---

## Describe the bug

A clear description of what the bug is.

## Steps to reproduce

1. Go to '...'
2. Click on '...'
3. See error

## Expected behavior

What you expected to happen.

## Actual behavior

What actually happened. Include any error messages from the DevTools console (Ctrl+Shift+I in the app).

## Environment

- **OS:** (e.g. Windows 11, macOS 14, Ubuntu 22)
- **App version:** (e.g. 1.0.0-beta.1)
- **Node version:** `node --version`
- **FFmpeg installed:** yes / no

## Screenshots or logs

If applicable, add screenshots or paste console output.
