---
name: Feature request
about: Suggest an idea or improvement
title: '[Feature] '
labels: enhancement
assignees: ''
---

## What problem does this solve?

Describe the workflow pain point or gap this would address. Context from a VFX production perspective is helpful.

## Proposed solution

What would you like to see? How should it work?

## Alternatives considered

Any alternative approaches or workarounds you've tried.

## Additional context

Mockups, references, or any other relevant information.
